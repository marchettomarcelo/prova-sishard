
# Explicação

Deixe aqui a sua explicação do que a função `funcao1` faz. Faça uma explicação breve e direta (uma frase ou linha).

Ex: se você acha que é uma função que calcula a raiz quadrada de um parâmetro, basta escrever aqui "Calcula e retorna a raiz quadrada do parâmetro utilizando..."

Sua resposta:
